/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sprite1 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Sprite1/costumes/costume1.png", {
        x: 454,
        y: 56
      }),
      new Costume("costume3", "./Sprite1/costumes/costume3.png", {
        x: 453,
        y: 56
      })
    ];

    this.sounds = [new Sound("pop", "./Sprite1/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.CLONE_START, this.startAsClone2)
    ];
  }

  *whenGreenFlagClicked() {
    this.size = 30;
    this.goto(0, 0);
    this.costume = "costume2";
    yield* this.generateRoadA(0);
  }

  *generateRoadA(speed) {
    this.visible = true;
    while (!this.touching("edge")) {
      this.costume = "costume1";
      this.createClone();
      this.size += 8;
      this.y += -15;
      yield* this.wait(0.1);
      this.costume = "costume2";
      this.createClone();
      this.size += 8;
      this.y += -15;
      yield* this.wait(0.1);
      yield;
    }
    this.costume = "costume1";
    this.createClone();
    this.size += 8;
    this.y += -15;
    yield* this.wait(0.1);
    this.costume = "costume2";
    this.createClone();
    this.size += 8;
    this.y += -15;
    yield* this.wait(0.1);
    this.visible = false;
  }

  *startAsClone() {
    while (true) {
      this.stage.vars.othersecret = this.stage.vars.secret;
      if (this.stage.vars.speedDpm > 0) {
        yield* this.wait(this.stage.vars.othersecret);
        this.costumeNumber += 1;
      }
      yield;
    }
  }

  *startAsClone2() {
    while (true) {
      if (this.keyPressed("a")) {
        this.x += 5;
      }
      if (this.keyPressed("d")) {
        this.x += -5;
      }
      yield;
    }
  }
}
