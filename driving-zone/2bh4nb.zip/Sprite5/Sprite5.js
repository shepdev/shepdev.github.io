/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sprite5 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("backdrop1", "./Sprite5/costumes/backdrop1.png", {
        x: 480,
        y: 360
      }),
      new Costume("costume1", "./Sprite5/costumes/costume1.png", {
        x: 480,
        y: 360
      })
    ];

    this.sounds = [new Sound("pop", "./Sprite5/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2)
    ];
  }

  *whenGreenFlagClicked() {
    this.stage.watchers.gear.visible = true;
    this.stage.watchers.speedDpm.visible = true;
    this.effects.ghost = 100;
    while (!(this.stage.vars.isexploded == 1)) {
      yield;
    }
    this.stage.watchers.gear.visible = false;
    this.stage.watchers.nitro.visible = false;
    this.stage.watchers.speedDpm.visible = false;
    yield* this.wait(2);
    this.costume = "backdrop1";
    for (let i = 0; i < 20; i++) {
      this.effects.ghost += -5;
      yield;
    }
    yield* this.wait(2);
    for (let i = 0; i < 20; i++) {
      this.effects.ghost += 5;
      yield;
    }
    this.costumeNumber += 1;
    for (let i = 0; i < 20; i++) {
      this.effects.ghost += -5;
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    this.stage.watchers.gear.visible = true;
    this.stage.watchers.nitro.visible = true;
    this.stage.watchers.speedDpm.visible = true;
    while (true) {
      yield* this.wait(0.3);
      this.moveAhead();
      yield;
    }
  }
}
