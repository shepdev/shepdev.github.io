/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sprite3 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Sprite3/costumes/costume1.svg", {
        x: 146.48856066107615,
        y: 36.680910625000024
      })
    ];

    this.sounds = [
      new Sound("pop", "./Sprite3/sounds/pop.wav"),
      new Sound("Alert", "./Sprite3/sounds/Alert.wav")
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked)
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
    while (true) {
      if (this.stage.vars.speedDpm > 160) {
        while (!(this.stage.vars.speedDpm < 160)) {
          this.visible = true;
          yield* this.playSoundUntilDone("Alert");
          this.visible = false;
          yield* this.wait(1);
          yield;
        }
      }
      yield;
    }
  }
}
