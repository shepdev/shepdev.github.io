/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Gear extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Gear/costumes/costume1.svg", { x: 0, y: 0 })
    ];

    this.sounds = [new Sound("pop", "./Gear/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked)
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      if (this.stage.vars.speedDpm > -1 && this.stage.vars.speedDpm < 55) {
        this.stage.vars.gear = 1;
      }
      if (this.stage.vars.speedDpm > 55 && this.stage.vars.speedDpm < 78) {
        this.stage.vars.gear = 2;
      }
      if (this.stage.vars.speedDpm > 78 && this.stage.vars.speedDpm < 120) {
        this.stage.vars.gear = 3;
      }
      if (this.stage.vars.speedDpm > 120 && this.stage.vars.speedDpm < 180) {
        this.stage.vars.gear = 4;
      }
      if (this.stage.vars.speedDpm > 180 && this.stage.vars.speedDpm < 220) {
        this.stage.vars.gear = 5;
      }
      if (this.stage.vars.speedDpm > 220 && this.stage.vars.speedDpm < 300) {
        this.stage.vars.gear = 6;
      }
      yield;
    }
  }
}
