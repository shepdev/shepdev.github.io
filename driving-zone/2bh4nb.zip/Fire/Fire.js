/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Fire extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Fire/costumes/costume1.png", { x: 26, y: 38 }),
      new Costume("costume2", "./Fire/costumes/costume2.png", { x: 26, y: 20 }),
      new Costume("costume3", "./Fire/costumes/costume3.png", { x: 18, y: 19 })
    ];

    this.sounds = [new Sound("pop", "./Fire/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2)
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      this.goto(this.sprites["Car2"].x, this.sprites["Car2"].y);
      this.y += -40;
      if (this.stage.vars.speedDpm > 160) {
        while (!(this.stage.vars.speedDpm < 160)) {
          this.createClone();
          yield;
        }
      }
      yield;
    }
  }

  *startAsClone() {
    this.visible = true;
    this.effects.clear();
    this.costume = this.random(1, 7);
    this.size = 50;
    this.x += this.random(-50, 50);
    for (let i = 0; i < 50; i++) {
      this.moveAhead();
      this.size += 1;
      this.effects.ghost += 2;
      this.y += 1;
      yield;
    }
    this.deleteThisClone();
  }

  *whenGreenFlagClicked2() {
    this.visible = false;
  }
}
