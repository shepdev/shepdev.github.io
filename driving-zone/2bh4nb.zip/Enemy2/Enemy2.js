/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Enemy2 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("11", "./Enemy2/costumes/11.png", { x: 52, y: 72 }),
      new Costume(
        "Explode-05-june[2",
        "./Enemy2/costumes/Explode-05-june[2.png",
        { x: 104, y: 124 }
      ),
      new Costume(
        "Explode-05-june[3",
        "./Enemy2/costumes/Explode-05-june[3.png",
        { x: 144, y: 154 }
      ),
      new Costume(
        "Explode-05-june[4",
        "./Enemy2/costumes/Explode-05-june[4.png",
        { x: 162, y: 168 }
      ),
      new Costume(
        "Explode-05-june[5",
        "./Enemy2/costumes/Explode-05-june[5.png",
        { x: 170, y: 172 }
      ),
      new Costume(
        "Explode-05-june[6",
        "./Enemy2/costumes/Explode-05-june[6.png",
        { x: 176, y: 168 }
      ),
      new Costume(
        "Explode-05-june[7",
        "./Enemy2/costumes/Explode-05-june[7.png",
        { x: 168, y: 172 }
      ),
      new Costume(
        "Explode-05-june[8",
        "./Enemy2/costumes/Explode-05-june[8.png",
        { x: 204, y: 180 }
      ),
      new Costume(
        "Explode-05-june[9",
        "./Enemy2/costumes/Explode-05-june[9.png",
        { x: 168, y: 166 }
      ),
      new Costume(
        "Explode-05-june[10",
        "./Enemy2/costumes/Explode-05-june[10.png",
        { x: 172, y: 186 }
      ),
      new Costume(
        "Explode-05-june[11",
        "./Enemy2/costumes/Explode-05-june[11.png",
        { x: 176, y: 168 }
      ),
      new Costume(
        "Explode-05-june[12",
        "./Enemy2/costumes/Explode-05-june[12.png",
        { x: 178, y: 172 }
      ),
      new Costume(
        "Explode-05-june[13",
        "./Enemy2/costumes/Explode-05-june[13.png",
        { x: 182, y: 180 }
      ),
      new Costume(
        "Explode-05-june[14",
        "./Enemy2/costumes/Explode-05-june[14.png",
        { x: 184, y: 180 }
      ),
      new Costume(
        "Explode-05-june[15",
        "./Enemy2/costumes/Explode-05-june[15.png",
        { x: 184, y: 180 }
      ),
      new Costume(
        "Explode-05-june[16",
        "./Enemy2/costumes/Explode-05-june[16.png",
        { x: 188, y: 174 }
      ),
      new Costume(
        "Explode-05-june[17",
        "./Enemy2/costumes/Explode-05-june[17.png",
        { x: 188, y: 176 }
      ),
      new Costume(
        "Explode-05-june[18",
        "./Enemy2/costumes/Explode-05-june[18.png",
        { x: 188, y: 176 }
      ),
      new Costume(
        "Explode-05-june[19",
        "./Enemy2/costumes/Explode-05-june[19.png",
        { x: 184, y: 172 }
      ),
      new Costume(
        "Explode-05-june[20",
        "./Enemy2/costumes/Explode-05-june[20.png",
        { x: 184, y: 162 }
      ),
      new Costume(
        "Explode-05-june[21",
        "./Enemy2/costumes/Explode-05-june[21.png",
        { x: 164, y: 160 }
      ),
      new Costume(
        "Explode-05-june[22",
        "./Enemy2/costumes/Explode-05-june[22.png",
        { x: 140, y: 152 }
      ),
      new Costume(
        "Explode-05-june[23",
        "./Enemy2/costumes/Explode-05-june[23.png",
        { x: 130, y: 148 }
      ),
      new Costume(
        "Explode-05-june[24",
        "./Enemy2/costumes/Explode-05-june[24.png",
        { x: 132, y: 148 }
      ),
      new Costume(
        "Explode-05-june[25",
        "./Enemy2/costumes/Explode-05-june[25.png",
        { x: 144, y: 142 }
      )
    ];

    this.sounds = [new Sound("explbomb", "./Enemy2/sounds/explbomb.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked)
    ];
  }

  *whenGreenFlagClicked() {
    this.size = 80;
    this.visible = false;
    while (!(this.stage.vars.speedDpm > 230)) {
      yield;
    }
    yield* this.wait(2.5);
    this.visible = true;
    this.broadcast("message1");
    yield* this.startSound("explbomb");
    this.costume = 11;
    for (let i = 0; i < 24; i++) {
      this.costumeNumber += 1;
      yield* this.wait(0.01);
      yield;
    }
    this.visible = false;
    yield* this.wait(5);
    this.broadcast("GAMEOVER");
  }
}
