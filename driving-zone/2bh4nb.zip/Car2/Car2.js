/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Car2 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("1i98oy-5", "./Car2/costumes/1i98oy-5.png", {
        x: 164,
        y: 100
      }),
      new Costume("1i98oy-2", "./Car2/costumes/1i98oy-2.png", {
        x: 176,
        y: 100
      }),
      new Costume("1i98oy-3", "./Car2/costumes/1i98oy-3.png", {
        x: 188,
        y: 100
      }),
      new Costume("1i98oy-4", "./Car2/costumes/1i98oy-4.png", {
        x: 212,
        y: 100
      }),
      new Costume("Boom", "./Car2/costumes/Boom.png", { x: 244, y: 119 })
    ];

    this.sounds = [
      new Sound("Pop", "./Car2/sounds/Pop.wav"),
      new Sound("Car Horn", "./Car2/sounds/Car Horn.wav")
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "message1" },
        this.whenIReceiveMessage1
      ),
      new Trigger(Trigger.KEY_PRESSED, { key: "f" }, this.whenKeyFPressed),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3)
    ];
  }

  *whenGreenFlagClicked() {
    this.costume = "1i98oy-5";
    this.stage.vars.speedDpm = 0;
    this.stage.vars.secret = 0.5;
    this.size = 60;
    while (true) {
      if (this.keyPressed("w")) {
        if (this.stage.vars.speedDpm < 250) {
          this.stage.vars.speedDpm += 1;
          this.stage.vars.secret += -0.005;
        }
        this.y += 1;
        yield* this.wait(0.1);
        this.y += -1;
      } else {
        while (
          !(
            this.stage.vars.speedDpm == 0 ||
            this.keyPressed("w") || this.keyPressed("c")
          )
        ) {
          this.stage.vars.speedDpm += -1;
          this.stage.vars.secret += 0.005;
          this.y += 1;
          yield* this.wait(0.1);
          this.y += -1;
          yield;
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    this.rotationStyle = Sprite.RotationStyle.LEFT_RIGHT;
    this.goto(0, -70);
    this.stage.vars.isexploded = 0;
    this.moveAhead();
    this.visible = true;
    while (true) {
      if (this.keyPressed("a")) {
        this.costume = "1i98oy-2";
        while (!!this.keyPressed("a")) {
          if (this.costumeNumber < 4) {
            this.direction = 90;
            this.costumeNumber += 1;
            yield* this.wait(0.1);
          }
          yield;
        }
        this.costume = "1i98oy-5";
      }
      if (this.keyPressed("d")) {
        this.costume = "1i98oy-2";
        while (!!this.keyPressed("d")) {
          if (this.costumeNumber < 4) {
            this.direction = -90;
            this.costumeNumber += 1;
            yield* this.wait(0.1);
          }
          yield;
        }
        this.costume = "1i98oy-5";
      }
      yield;
    }
  }

  *whenIReceiveMessage1() {
    this.stage.vars.isexploded += 1;
    this.costume = "Boom";
    yield* this.wait(2.1);
    this.visible = false;
  }

  *whenKeyFPressed() {
    this.stage.vars.nitro = 1;
    while (!!this.keyPressed("f")) {
      yield;
    }
    this.stage.vars.nitro = 0;
  }

  *whenGreenFlagClicked3() {
    while (true) {
      if (this.keyPressed("h")) {
        yield* this.startSound("Car Horn");
      }
      yield;
    }
  }
}
