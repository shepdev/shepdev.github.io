/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sprite6 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Sprite6/costumes/costume1.png", {
        x: -340,
        y: 299
      }),
      new Costume("costume2", "./Sprite6/costumes/costume2.png", {
        x: 457,
        y: 271
      }),
      new Costume("costume3", "./Sprite6/costumes/costume3.png", {
        x: 468,
        y: 278
      })
    ];

    this.sounds = [new Sound("pop", "./Sprite6/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.CLONE_START, this.startAsClone2)
    ];
  }

  *startAsClone() {
    this.visible = true;
    while (!this.touching("edge")) {
      if (this.stage.vars.speedDpm > 0) {
        yield* this.wait(this.stage.vars.secret);
        this.y += -15;
        this.size += 8;
      }
      yield;
    }
    this.deleteThisClone();
  }

  *whenGreenFlagClicked() {
    this.visible = false;
    this.size = 30;
    this.goto(0, 0);
    this.costume = "costume2";
    while (true) {
      yield* this.signperspective();
      yield;
    }
  }

  *signperspective() {
    this.costume = this.random(1, 3);
    this.createClone();
    yield* this.wait(this.random(1, 10));
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (this.keyPressed("a")) {
        this.x += 5;
      }
      if (this.keyPressed("d")) {
        this.x += -5;
      }
      yield;
    }
  }

  *startAsClone2() {
    while (true) {
      if (this.keyPressed("a")) {
        this.x += 5;
      }
      if (this.keyPressed("d")) {
        this.x += -5;
      }
      yield;
    }
  }
}
