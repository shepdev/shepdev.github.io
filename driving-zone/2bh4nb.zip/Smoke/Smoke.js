/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Smoke extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Smoke/costumes/costume1.png", {
        x: 35,
        y: 31
      }),
      new Costume("costume2", "./Smoke/costumes/costume2.png", {
        x: 41,
        y: 18
      }),
      new Costume("costume3", "./Smoke/costumes/costume3.png", {
        x: 30,
        y: 60
      }),
      new Costume("costume4", "./Smoke/costumes/costume4.png", {
        x: 45,
        y: 24
      }),
      new Costume("costume5", "./Smoke/costumes/costume5.png", {
        x: 46,
        y: 35
      }),
      new Costume("costume6", "./Smoke/costumes/costume6.png", {
        x: 34,
        y: 28
      }),
      new Costume("costume7", "./Smoke/costumes/costume7.png", { x: 39, y: 32 })
    ];

    this.sounds = [new Sound("pop", "./Smoke/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3)
    ];
  }

  *startAsClone() {
    this.visible = true;
    this.effects.clear();
    this.costume = this.random(1, 7);
    this.size = 50;
    this.x += this.random(-50, 50);
    for (let i = 0; i < 50; i++) {
      this.moveAhead();
      this.size += 1;
      this.effects.ghost += 2;
      this.y += 1;
      yield;
    }
    this.deleteThisClone();
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *whenGreenFlagClicked2() {
    while (true) {
      this.goto(this.sprites["Car2"].x, this.sprites["Car2"].y);
      this.y += -40;
      if (this.stage.vars.speedDpm > 140) {
        while (!(this.stage.vars.speedDpm < 140)) {
          this.createClone();
          yield* this.wait(0.1);
          yield;
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked3() {
    while (true) {
      if (this.keyPressed("s")) {
        while (!!this.keyPressed("s")) {
          this.createClone();
          if (this.stage.vars.speedDpm > 5) {
            this.stage.vars.speedDpm += -3;
          }
          yield;
        }
      }
      yield;
    }
  }
}
