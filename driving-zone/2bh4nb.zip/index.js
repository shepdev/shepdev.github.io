import { Project } from "https://unpkg.com/leopard@^1/dist/index.esm.js";

import Stage from "./Stage/Stage.js";
import Car2 from "./Car2/Car2.js";
import Sensor from "./Sensor/Sensor.js";
import Smoke from "./Smoke/Smoke.js";
import Sprite1 from "./Sprite1/Sprite1.js";
import Sprite2 from "./Sprite2/Sprite2.js";
import Sprite4 from "./Sprite4/Sprite4.js";
import Fire from "./Fire/Fire.js";
import Gear from "./Gear/Gear.js";
import Sprite3 from "./Sprite3/Sprite3.js";
import Enemy2 from "./Enemy2/Enemy2.js";
import Sprite5 from "./Sprite5/Sprite5.js";
import Cruise from "./Cruise/Cruise.js";
import Sprite6 from "./Sprite6/Sprite6.js";

const stage = new Stage({ costumeNumber: 2 });

const sprites = {
  Car2: new Car2({
    x: 0,
    y: -69,
    direction: 90,
    costumeNumber: 5,
    size: 60,
    visible: false,
    layerOrder: 12
  }),
  Sensor: new Sensor({
    x: 36,
    y: 28,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 1
  }),
  Smoke: new Smoke({
    x: 0,
    y: -109,
    direction: 90,
    costumeNumber: 6,
    size: 100.00000000000003,
    visible: false,
    layerOrder: 2
  }),
  Sprite1: new Sprite1({
    x: 0,
    y: -180,
    direction: 90,
    costumeNumber: 1,
    size: 126.00000000000003,
    visible: false,
    layerOrder: 3
  }),
  Sprite2: new Sprite2({
    x: -203,
    y: 73.00000000000001,
    direction: 21,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 5
  }),
  Sprite4: new Sprite4({
    x: -205,
    y: 75,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 4
  }),
  Fire: new Fire({
    x: 0,
    y: -109,
    direction: 90,
    costumeNumber: 1,
    size: 100.00000000000003,
    visible: false,
    layerOrder: 9
  }),
  Gear: new Gear({
    x: 36,
    y: 28,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 6
  }),
  Sprite3: new Sprite3({
    x: 12,
    y: 151,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 7
  }),
  Enemy2: new Enemy2({
    x: -1.000000000000007,
    y: -97,
    direction: 90,
    costumeNumber: 25,
    size: 80,
    visible: false,
    layerOrder: 8
  }),
  Sprite5: new Sprite5({
    x: 0,
    y: 0,
    direction: 90,
    costumeNumber: 2,
    size: 100,
    visible: true,
    layerOrder: 13
  }),
  Cruise: new Cruise({
    x: 0,
    y: -109,
    direction: 90,
    costumeNumber: 1,
    size: 50,
    visible: true,
    layerOrder: 11
  }),
  Sprite6: new Sprite6({
    x: -15,
    y: 0,
    direction: 90,
    costumeNumber: 3,
    size: 30,
    visible: false,
    layerOrder: 10
  })
};

const project = new Project(stage, sprites, {
  frameRate: 30 // Set to 60 to make your project run faster
});
export default project;
