/* eslint-disable require-yield, eqeqeq */

import {
  Stage as StageBase,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Stage extends StageBase {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("backdrop1", "./Stage/costumes/backdrop1.png", {
        x: 480,
        y: 360
      }),
      new Costume("backdrop2", "./Stage/costumes/backdrop2.png", {
        x: 480,
        y: 360
      })
    ];

    this.sounds = [new Sound("pop", "./Stage/sounds/pop.wav")];

    this.triggers = [];

    this.vars.speedDpm = 21;
    this.vars.secret = 0.6550000000000001;
    this.vars.gear = 1;
    this.vars.isexploded = 1;
    this.vars.othersecret = 0.6400000000000001;
    this.vars.secret2 = 0;
    this.vars.nitro = 0;
    this.vars.nitroOffset = 2;

    this.watchers.speedDpm = new Watcher({
      label: "speed DPM",
      style: "large",
      visible: false,
      value: () => this.vars.speedDpm,
      x: 251,
      y: 43
    });
    this.watchers.gear = new Watcher({
      label: "Gear:",
      style: "normal",
      visible: false,
      value: () => this.vars.gear,
      x: 245,
      y: 175
    });
    this.watchers.nitro = new Watcher({
      label: "nitro",
      style: "normal",
      visible: false,
      value: () => this.vars.nitro,
      x: 245,
      y: 147
    });
  }
}
