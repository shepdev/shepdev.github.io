/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Cruise extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Cruise/costumes/costume1.png", {
        x: 26,
        y: 55
      }),
      new Costume("costume2", "./Cruise/costumes/costume2.png", {
        x: 26,
        y: 46
      }),
      new Costume("costume3", "./Cruise/costumes/costume3.png", {
        x: 18,
        y: 43
      })
    ];

    this.sounds = [new Sound("pop", "./Cruise/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone)
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      this.goto(this.sprites["Car2"].x, this.sprites["Car2"].y);
      this.y += -40;
      if (this.stage.vars.nitro == 1) {
        while (!(this.stage.vars.nitro == 0)) {
          this.stage.vars.speedDpm += 1;
          this.createClone();
          yield;
        }
      }
      yield;
    }
  }

  *startAsClone() {
    this.visible = true;
    this.effects.clear();
    this.costume = this.random(1, 7);
    this.size = 50;
    this.stage.vars.nitroOffset = this.random(1, 2);
    if (this.stage.vars.nitroOffset == 1) {
      this.x += this.random(-45, -35);
    }
    if (this.stage.vars.nitroOffset == 2) {
      this.x += this.random(45, 35);
    }
    for (let i = 0; i < 50; i++) {
      this.moveAhead();
      this.size += 1;
      this.effects.ghost += 2;
      this.y += 1;
      yield;
    }
    this.deleteThisClone();
  }
}
